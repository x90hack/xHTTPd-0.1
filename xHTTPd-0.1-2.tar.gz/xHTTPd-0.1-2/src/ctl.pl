#!/usr/bin/perl -w

sub MALLOC_FAIL_FREE()
{
        $ENV{MALLOC_CHECK_} = 0;
}
sub UNSET_ENV
{
        $ENV{MALLOC_CHECK_} = '';
}

if($#ARGV != 0){
    print "\nxHTTPd Control Interface...\n\n";
    print "./ctl [start|stop|restart]\n\n";
    exit(-1);
}

$PROGRAM_NAME = "xHTTPd";

$command = $ARGV[0];

if($command eq "start"){
    MALLOC_FAIL_FREE();
    system("./".$PROGRAM_NAME." &");
    print $PROGRAM_NAME."\n[ START ]\n\n";

} elsif($command eq "restart"){
    system("pkill -9 ".$PROGRAM_NAME);
    MALLOC_FAIL_FREE();
    system($PROGRAM_NAME." &");
    print $PROGRAM_NAME."\n[ RESTART ]\n\n";

} elsif($command eq "stop"){
    UNSET_ENV();
    system("pkill -9 ".$PROGRAM_NAME);
    print $PROGRAM_NAME." \n[ STOP ]\n\n";

}

