/*
 * xHTTPd daemon.
 * Copyright(c) x90 all rights reserved.
 * Email: x90cx90c1@gmail.com
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "main.h"

/*
 * MIME �ļ�
*/
int
parse_data( struct _PARSED_MIME *pPMIME, char *string, int len, char *delim )
{
    register char *request = NULL;
    int i = 0;

    /* �޼ҵ� �Ľ� ( �޼ҵ�, URL, HTTP ���� ) */
    request = malloc( len + 1 );
    if( !request ){
        fprintf( stderr, "parse_data:: memory alloc failed\n" );
        return -1;
    }
    memset( request, 0, len + 1 );
    memcpy( ( void * ) request, string, len ); 

    if( strstr(request, "\%n") || strstr(request, "\%hn") )
    {
      fprintf( stderr, "parse_data: format string bug attack detected\n");
      return -2;
    } 
    *( request + len ) = '\x00';

    if( parse_METHOD( request, pPMIME ) != 0 )
    {
        fprintf( stderr, "parse_data:: parse_METHOD error!\n" );
        free( request );
        request = NULL;
        return -2;
    }

    /* Host: �Ľ� */
    memset( request, 0, len + 1 );
    memcpy( ( void * ) request, string, len );
    *( request + len ) = '\x00';

    if( parse_HOST( request, pPMIME ) != 0 )
    {
        fprintf( stderr, "parse_data:: parse_HOST error!\n" );
        free( request );
        request = NULL;
        return -3;
    }

    /* AcceptLanguage: �Ľ� */
    memset( request, 0, len + 1 );
    memcpy( ( void * ) request, string, len );
    *( request + len ) = '\x00';

    parse_LANG( request, pPMIME );

    /* Content-Type: �Ľ� */
    memset( request, 0, len + 1 );
    memcpy( ( void * ) request, string, len );
    *( request + len ) = '\x00';
    
    if( parse_ContentType( request, pPMIME ) != 0 )
    {
        fprintf( stderr, "parse_data:: parse_ContentType error!\n" );
        if( request != NULL )
        {   
            free( request );
            request = NULL;
            return -4;
        }
    }

    memset( request, 0, len + 1 );
    memcpy( ( void * ) request, string, len );

    /* ASCII HexDecimal ���ڵ� ( ex. %2f%20%20 ) */
    asciiHex_decoding( request, pPMIME );

    /* Base64 ��Ű ���ڵ�, �Ľ� ( request �����Ǿ��� ) */
    if( base64_Cookie_decoding( request, pPMIME ) == 0 )
    {
        printf("[ base64 + Hex DECODED Cookie ]\n");
        for( i = 0; i < MAX_COOKIE; i++ )
        {
            if( *pPMIME->cookie[i].var == '\x00')
            {
                break;
            }
            printf("\t$_COOKIE[%s] = [%s]\n", pPMIME->cookie[i].var,
                                            pPMIME->cookie[i].val );
         }

    }

    /* POST ����Ÿ �Ľ� */
    if( pPMIME->method.type == METHOD_POST )
    {
        if( parse_POST_data( request, pPMIME ) != 0 )
        {
            fprintf( stderr, "parse_data:: parse_POST_data error!\n" );
            if( request != NULL )
            {
                free( request );
                request = NULL;
                return -5;
            }
        }
        
        printf("\n\n[ POST Variables ]\n");

        for( i = 0; i < MAX_POST_VAR; i++ )
        {
            if( *pPMIME->post_data[i].var == '\x00')
            {
                break;
            }
            printf("\t$_POST [%s] = [%s]\n", 
                    pPMIME->post_data[i].var,
                    pPMIME->post_data[i].val );
        }
    }
    
    free( request );
    request = NULL;

    return 0;
}

/*
 * �޼ҵ� �Ľ�
*/
int 
parse_METHOD( char *request, struct _PARSED_MIME *pPMIME )
{
    char *p;
    char *str1, *str2, *str3;
    char *token = " ", *token_feed = "\n";
    int str1_len = 0, str2_len = 0, str3_len = 0;

#ifdef _DEBUG
    printf("req:-%s-\n", request);
#endif

    /* METHOD �Ľ� */
    str1 = strtok_r( request, token, &p );
    if( str1 == NULL )
    {
        return - 1;
    }

    str2 = strtok_r( NULL, token, &p );
    if( str2 == NULL )
    {
        return -2;
    }

    str3 = strtok_r( NULL, token_feed, &p );
    if( str3 == NULL )
    {
        return -3;
    }

#ifdef _DEBUG
    printf("str1=-%s-str2=-%s-str3=-%s-\n", str1, str2, str3);
#endif

    if( strncmp( str1, "QUIT", 4 ) == 0 )
    {
        pPMIME->command1_1 = COMMAND_QUIT;
        return -4;
    }
    
    if( str1 != NULL )
    {
        str1_len = strlen( str1 );
        if( str1_len > 5 )
        {
            fprintf( stderr, " requested METHOD was over 5 bytes.\n" );
            return -5;
        } 
        else
        {
            if( strncmp( str1, "GET", 3 ) == 0 )
            {
                pPMIME->method.type = METHOD_GET;
            }
            else if( strncmp( str1, "POST", 4 ) == 0 )
            {
                pPMIME->method.type = METHOD_POST;
            }
            else if( strncmp( str1, "HEAD", 4 ) == 0 )
            {
                pPMIME->method.type = METHOD_HEAD;
            }
        }
    } 
    else
    {
         pPMIME->method.type = METHOD_UNKNOWN;
    }

    /* URL �Ľ� */
    if( str2 != NULL )
    {
        str2_len = strlen( str2 );
  
        if( str2_len >= MAX_URL )
        {
            fprintf( stderr, "requested URL was over %d bytes.\n ", MAX_URL );
            return -6;
        } 
        else 
        {
            pPMIME->method.url = malloc( str2_len + 1 );
            if( !pPMIME->method.url )
            {
                fprintf( stderr, "parse_METHOD:: memory alloc failed.!\n" );
                return -7;
            }
            memset( pPMIME->method.url, 0, str2_len + 1 );
            memcpy( pPMIME->method.url, str2, str2_len );
            *( pPMIME->method.url + str2_len ) = '\x00';
            
            /* ../../ ���丮 Ʈ������ üŷ */
            if( checking_dir_traverse( pPMIME->method.url ) == -1 )
            {
                fprintf( stderr, "parse_METHOD:: dir traversal detected!\n" );
                
                if( pPMIME->method.url != NULL )
                {
                    free( pPMIME->method.url );
                    pPMIME->method.url = NULL;
                }
                
                return -8;                                                                  }
            }
            
    } 

#ifdef _DEBUG
    printf("url=-%s-\n", pPMIME->method.url);
#endif

    /* VERSION �Ľ� */
    if( str3 != NULL )
    {
        str3_len = strlen( str3 );

        if ( str3_len > 12 )
        {   // \r\n\r\n �����Ͽ� 12����Ʈ ����
            fprintf( stderr, "requested HTTP version was over 12 bytes.\n" );
            return -8;
        } 
        else
        {
            if( strncmp( str3, "HTTP/1.0", 8 ) == 0 )
            {
                pPMIME->method.version = VERSION_1_0;
            } 
            else if ( strncmp( str3, "HTTP/1.1", 8 ) == 0 )
            {
                pPMIME->method.version = VERSION_1_1;
            }
        }
    } 
    else
    {
         pPMIME->method.version = VERSION_UNKNOWN;
    }

#ifdef _DEBUG
    printf("version=%x\n", pPMIME->method.version);
#endif

    return 0;
}

/*
 * ȣ��Ʈ �Ľ�
*/
int 
parse_HOST( char *request, struct _PARSED_MIME *pPMIME )
{
    char *p;
    char *str1, *str2;
    char *cut_method_token = "\n";
    char *token_host = ":";
    char *token_end = "\n";
    char *end_byte = '\x00';
    int str1_len = 0;
    
    char *tmp;

    if( ( str1 = strstr( request, "Host: " ) ) != NULL )
    {
        if( *( str1 - 1 ) == '\n' ) // ^Host:
        {
            str1 += 6;

            if( ( end_byte = strstr( str1, token_end ) ) != NULL )
            {
                *(end_byte - 1) = '\x00';
            }
            str1 = strtok_r( str1, token_host, &p );
            str2 = strtok_r( NULL, token_end, &p );
       
#ifdef _DEBUG
            printf("str1=-%s-\n", str1);
#endif

            if( str1 != NULL )
            {
                str1_len = strlen( str1 );

                if( str1_len > 15 )
                {
                    fprintf( stderr, "requested Host: 's servername was over 15bytes\n" );
                    return -1;
                }
                else{
                    //printf( "str1=-%s-%d\n", str1, str1_len );
                    pPMIME->host.ipaddr = malloc( str1_len + 1 );
                     
                    if( !pPMIME->host.ipaddr )
                    {
                        fprintf( stderr, "parse_HOST:: memory alloc failed!\n");
                        return -2;
                    }
                    memset( pPMIME->host.ipaddr, 0,  str1_len + 1 );
                    memcpy( pPMIME->host.ipaddr, str1, str1_len );
                    *( pPMIME->host.ipaddr + str1_len ) = '\x00';

                    if( str2 != NULL )
                    {
                        pPMIME->host.port = atoi( str2 );
                    } 
                    else
                    {
                        pPMIME->host.port = -1;
                    }
                }
            }
        } 
        else
        {
            return -2;
        }
    } 
    else
    {
        return -3;
    }

    return 0;
}

/*
 * AcceptLanguage: �Ľ�
*/
int 
parse_LANG( char *request, struct _PARSED_MIME *pPMIME )
{
    char *str1 = NULL, *str2 = NULL;
    char *token = "\n";
    char *token_end = "\n";
    char *p = NULL;
    char *end_byte = '\x00';

    if( ( str1 = strstr( request, "Accept-Language: " ) ) != NULL )
    {
        if( *( str1 - 1 ) == '\n' )
        {
            str1 += 17;

            if( ( end_byte = strstr( str1, token_end ) ) != NULL )
            {
                *(end_byte - 1) = '\x00';
            }

            str1 = strtok_r( str1, token, &p );

#ifdef  _DEBUG
            printf( "Accept-Language:-%s-\n", str1 );
#endif

            if( strncmp( str1, "ko", 2 ) == 0 )
            {
                sprintf( pPMIME->lang, "euc-kr\0" );
            }
            else if( strncmp( str1, "cn", 2) == 0 )
            {
                sprintf( pPMIME->lang, "euc-cn\0" );
            }
            else if( strncmp( str1, "jp", 2) == 0 )
            {
                sprintf( pPMIME->lang, "euc-jp\0" );
            }
            else if( strncmp( str1, "UTF-8", 5) == 0 )
            {
                sprintf( pPMIME->lang, "UTF-8\0" );
            }
            else
            {
                sprintf( pPMIME->lang, "UTF-8\0" );
            }
        }
    }
    else
    {
        sprintf( pPMIME->lang, "UTF-8\0" );
    }
    
    return 0;
}

int checking_dir_traverse( char *url )
{

    
    if( strstr( url, "../" ) != NULL )
    {
        fprintf( stderr, "checking_dir_traverse:: ../ tried!\n" );     
        return -1;
    } 
    else if( strstr( url, "..../" ) != NULL )
    {
        fprintf( stderr, "checking_dir_traverse:: ..../ tried!\n" );
        return -1;
    }
    else if( strstr( url, "../../../../../../../../../../../../../../../../") != NULL)
    {
        fprintf( stderr, "checking_dir_traverse:: ../ ... x 16 more over tried!\n" );
        return -1;
    }

}

/*
   Content-Type: �Ľ�
*/
int parse_ContentType( char *request, struct _PARSED_MIME *pPMIME )
{
    char *str1 = NULL, *str2 = NULL, *p = NULL;

    if( ( str1 = strstr( request, "Content-Type: " ) ) != NULL )
    {
        if( *( str1 - 1 ) == '\n' )
        {
           str1 += 14;
           
           if( ( str2 = strstr( str1, "\n" ) ) != NULL )
           {
                *( str2 ) = '\x00';
                if ( *( str2 - 1 ) == '\r' ) {
                    *( str2 - 1 ) = '\x00';
                }
                if( strncmp( str1, "text/html", 9 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_HTML;
                }
                if( strncmp( str1, "application/x-httpd-php", 23) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_PHP;
                } 
                else if( strncmp( str1, "image/jpg", 9 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_JPG;
                }
                else if( strncmp( str1, "image/gif", 9 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_GIF;
                }
                else if( strncmp( str1, "image/png", 9 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_PNG;
                }
                else if( strncmp( str1, "image/tiff", 10 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_TIFF;
                }
                else if( strncmp( str1, "image/ico", 9 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_ICO;
                }
                else if( strncmp( str1, "text/javascript", 15 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_JS;
                }
                else if( strncmp( str1, "application/x-shockwave-flash", 29 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_SWF;
                }
                else if( strncmp( str1, "application/x-www-form-urlencoded", 33 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_APP_X_WWW_FORM_URLENCODED;
                }
                else if( strncmp( str1, "audio/x-mpeg-3", 15 ) == 0 )
                {
                    pPMIME->content_type = CONTENT_TYPE_MP3;
                } 
                else
                {
                    pPMIME->content_type = CONTENT_TYPE_HTML;
                }

           }
           else
           {
               pPMIME->content_type = CONTENT_TYPE_HTML;
           }
        }
        else 
        {
            pPMIME->content_type = CONTENT_TYPE_HTML;
        }
    }
    else
    {
        pPMIME->content_type = CONTENT_TYPE_HTML;
    }

   return 0; 
}

/*
   Base64 Cookie ���ڵ�
*/
int base64_Cookie_decoding( char *request, struct _PARSED_MIME *pPMIME )
{
    char *str1 = NULL, *str2 = NULL, *str3 = NULL, *endstr = NULL;
    int var_len = 0, val_len = 0;
    char var[ 128 ], val[ 256 ];
    char cookie_plain[ 1024 ];
    char request_plain[ strlen( request ) ];
    char *cookie_begin = NULL, *cookie_finish = NULL;
    char *base64 = NULL;
    char *body_begin = NULL;
    int flag_endcookie = 0;
    int cookie_i = 0, i = 0, j = 0;
    int res = 0;
    char header_data[ 1024 ];
    int request_len = strlen( request );

    memset( header_data, 0, sizeof(header_data));

    if( ( body_begin = strstr( request, "\r\n\r\n" ) ) != NULL) 
    {
        if( (body_begin - request) - 1 >= sizeof( header_data ) )
        {
            fprintf( stderr, "base64_cookie_decode:: long MIME!!\n" );
            return -1;
        }
        body_begin += 4;
        memcpy( (void * ) header_data, request, body_begin - request );
    }
    else if( ( body_begin = strstr( request, "\n\n" ) ) != NULL )
    {
        if( (body_begin - request ) - 1 >= sizeof( header_data ) )
        {
            fprintf( stderr, "base64_cookie_decode:: long MIME!!\n" );
            return -2;
        }
        body_begin += 2;
        memcpy( ( void *) header_data, request, body_begin - request );
    }

    sprintf( cookie_plain, "Cookie: " );

    memset( request_plain, 0, sizeof ( request_plain ) );
    memset( var, 0, sizeof( var ) );
    memset( val, 0, sizeof( val ) );
    memset( cookie_plain, 0, sizeof( cookie_plain ) );

    if( ( str1 = strstr( header_data, "Cookie: " ) ) != NULL )
    {
        if( *( str1 - 1 ) == '\n' )
        {
            for(i = 0; i < MAX_COOKIE; i++)
            {
                *(pPMIME->cookie[i].var) = '\x00';
                *(pPMIME->cookie[i].val) = '\x00';
            }

            cookie_begin = str1;
            str1 += 8;
            
            if( ( endstr = strstr( str1, "\n" ) ) == NULL )
            {
                return -3;
            }

            while(1){
                if( ( str2 = strstr( str1, "=" ) ) != NULL )
                {
                    var_len = ( str2 - str1 );
                    
                    if( var_len >= (MAX_COOKIE_DATA_VAR_NAME - 1) )
                    {
                        fprintf( stderr, "base64_cookie_decoding:: long var name\n" );
                        res = -4;
                        goto out;
                    }
                    memcpy( ( void * ) var, str1, var_len );
                    *( var +  var_len ) = '\x00';

                    str2 += 1;
                
                    if( ( str3 = strstr( str2, ";" ) ) != NULL )
                    {
                        val_len = ( str3 - str2 );
                        if( var_len >= (MAX_COOKIE_DATA_VAR_NAME - 1) ){
                            fprintf( stderr, "base64_cookie_decoding:: long val \n");
                            res = -5;
                            goto out;
                        }
                        memcpy( ( void * ) val, str2, val_len );
                        *( val + val_len ) = '\x00';
                    }
                    else if( ( str3 = strstr( str2, "\r" ) ) != NULL )
                    {
                        val_len = ( str3 - str2 );
                        if( var_len >= (MAX_COOKIE_DATA_VAL - 1)){
                            fprintf( stderr, "base64_cookie_decoding:: long val\n" );
                            res = -6;
                            goto out;
                        }
                        memcpy( ( void * ) val, str2, val_len );
                        *( val + val_len ) = '\x00';
                        
                        str1 = NULL;
                        str2 = NULL;
                        str3 = NULL;

                        flag_endcookie = 1;
                        goto decode_step;
                    }
                    else if( ( str3 = strstr( str2, "\n" ) ) != NULL )
                    {
                        val_len = ( str3 - str2 );

                        if( val_len >= MAX_COOKIE_DATA_VAL - 1 )
                        {
                           fprintf( stderr, "base64_cookie_decoding:: long cookie val\n");                           res = -7;
                           goto out;
                        }
                        memcpy( ( void * ) val, str2, val_len );
                        *( val + val_len ) = '\x00';

                        str1 = NULL;
                        str2 = NULL;
                        str3 = NULL;

                        flag_endcookie = 1;
                        goto decode_step;
                    }
                    else
                    {
                        str1 = NULL;
                        str2 = NULL; 
                        str3 = NULL;
                        break;
                        
                    }

                    str1 = ( str3 + 1 );
                    if( *( str1 ) == ' ' )
                    {
                        str1 ++;
                    }
decode_step:
                    /* is it encoded ? then decode */            
                    if( is_base64_encoded( val ) == 0 ){
                        base64 = x90c_base64_decode ( val );
                        sprintf( cookie_plain, "%s%s=%s; ", cookie_plain,                                                  var, base64 );
                        memcpy(pPMIME->cookie[ cookie_i ].var, var, strlen( var ) );
                        memcpy(pPMIME->cookie[ cookie_i ].val, base64, strlen( base64 ) );
                        *(pPMIME->cookie[ cookie_i ].var + strlen(var)) = '\x00';
                        *(pPMIME->cookie[ cookie_i ].val + strlen(base64)) = '\x00';

                        if( base64 != NULL )
                        {
                            free( base64 );
                            base64 = NULL;
                        }
                    } 
                    else
                    {
                        sprintf( cookie_plain, "%s%s=%s; ", cookie_plain,
                                var, val );
                        memcpy(pPMIME->cookie[ cookie_i ].var, var, strlen(var));
                        memcpy(pPMIME->cookie[ cookie_i ].val, val, strlen(val));;
                        *(pPMIME->cookie[ cookie_i ].var + strlen(var)) = '\x00';
                        *(pPMIME->cookie[ cookie_i ].val + strlen(val)) = '\x00';
                    }
                    
                    cookie_i ++;

                    memset( var, 0, sizeof( var ) );
                    memset( val, 0, sizeof( val ) );

                    if( cookie_i > MAX_COOKIE )
                    {
                        flag_endcookie = 1;
                    }
                     
                    if( flag_endcookie == 1 )
                    {
                        break;
                    }

                    str2 = NULL;
                    str3 = NULL;
                }
                else
                {
                    str1 = NULL;
                    str2 = NULL;
                    str3 = NULL;
                    break;
                }
                
            }
        }
        
        cookie_plain[ strlen( cookie_plain) ] = '\x00';
//        printf("Base64 Decoded Cookie:-%s-\n", cookie_plain );  

        memcpy( ( void * ) request_plain, request, cookie_begin - header_data );
        memcpy( ( void * ) ( request_plain + ( cookie_begin - header_data ) ), 
                cookie_plain, strlen( cookie_plain ) );
        sprintf( request_plain, "%s\r\n\r\n", request_plain );
        memcpy( ( void * ) request_plain, body_begin, 
                ((request + strlen( request)) + 1) - body_begin );
    }
           
 //   printf( "DECODED:\n-%s-\n",  request_plain );

    memset( request, 0, request_len + 1 );
    memcpy( ( void * ) request, header_data, strlen(header_data));
    memcpy( ( void * ) (request + strlen(header_data)), request_plain, 
            strlen( request_plain) );

    *( request + strlen(header_data) + strlen( request_plain ) ) = '\x00';

out:
    if( res != 0 )
    {
       for( j = 0; j < MAX_COOKIE; j++ )
       {
            if(*(pPMIME->cookie[j].var) == '\x00')
            {
                break;
            }
                *(pPMIME->cookie[j].var) = '\x00';
                *(pPMIME->cookie[j].val) = '\x00';
       }
    }

    return res;

}

/*
   ASCII HexDecimal Decoding
*/
int asciiHex_decoding( char *request, struct _PARSED_MIME *pPMIME )
{
    char *plain_str = NULL;
    
    plain_str = hex_decode( request );

    memset( request, 0, strlen( request ) + 1 );
    memcpy( ( void * ) request, plain_str, strlen( plain_str ) );
    *(plain_str + strlen(plain_str)) = '\x00';

    return 0;
}

/*
   POST ����Ÿ �Ľ� 
*/
int parse_POST_data( char *request, struct _PARSED_MIME *pPMIME )
{
    char *str1 = NULL, *str2 = NULL;
    char token = '=', token_center = '&';
    int i = 0;
    int res = 0;

    if( (str1 = strstr( request, "\r\n\r\n" )) == NULL )
    {
            fprintf( stderr, "parse_POST_data:: No data\n" );
            res = -1;
            return res;   
    }

    str1 += 4;

    // post_data[].*var*val initialized
    for( i = 0; i < MAX_POST_VAR; i++ )
    {
        *(pPMIME->post_data[i].var) = '\x00';
        *(pPMIME->post_data[i].val) = '\x00';
    }

    for( i = 0; i < MAX_POST_VAR; i++ )
    {
        if( (str2 = strchr( str1, token )) == NULL && i == 0)
        {
            fprintf( stderr, "parse_POST_data:: no post vars\n" );
            res = -2;
            goto out;
        }
        
        if( (str2 - str1) >= MAX_POST_DATA_VAR_NAME - 1 )
        {
            fprintf( stderr, "parse_POST_data:: long post var name!\n" );
            res = -3;
            goto out;
        }
        memcpy( pPMIME->post_data[i].var, str1, str2 - str1 );
        *(pPMIME->post_data[i].var + (str2 - str1)) = '\x00';

        str2++;
        if( (str1 = strchr( str2, token_center )) == NULL ){
            if( strlen( str2 ) >= (MAX_POST_DATA_VAL - 1) )
            {
                fprintf( stderr, "parse_POST_data:: long post var value!\n" );
                res = -4;
                goto out;
            }
            memcpy( pPMIME->post_data[i].val, str2, strlen( str2 ) );
            *(pPMIME->post_data[i].val + (strlen( str2 ))) = '\x00';
            goto out;
        }
        else
        {
            if( (strlen( str2 ) - 1) >= (MAX_POST_DATA_VAL - 1 )){
                fprintf( stderr, "parse_POST_data:: long post var value!\n" );
                res = 5;
                goto out;
            }
            memcpy( pPMIME->post_data[i].val, str2, strlen( str2 ) - 1 );
            *(pPMIME->post_data[i].val + ((str1 - str2) )) = '\x00';
            str1 ++;
        }
    }

out:
    return res;
}


