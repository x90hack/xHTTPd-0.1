/*

    hex.c ( %2f%20%2f -> / / )

    Date: 17.12.2009 
    URL : x90c.org

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *hex_decode( char *string )
{
    int i = 0, j =0;
    int str_len = strlen( string );
    char *str1 = NULL, *str2 = NULL;
    char bytes[3] = "\x00\x00\x00";
    char real_ascii = '\x00';
    char *plain_str = NULL;

    plain_str = malloc( str_len + 1 );

    if( !plain_str )
    {
        fprintf( stderr, "hex_decode:: Memory allocation fail\n" );
        return (char *)-1;
    }

    memset( plain_str, 0, str_len + 1 );

    for( j = 0, str1 = string; *str1 != '\x00'; j++)
    {
        if( *str1 == '%' ){
            str1++;
            bytes[0] = *( str1);
            bytes[1] = *( str1 + 1 );
            bytes[2] = '\x00';
            str1 += 2;
            real_ascii = (char)strtol(bytes, NULL, 16);
            //if( isprint(real_ascii) )
            //{
                *(plain_str + j) = real_ascii;
            //}
        }    
        else
        {
            *(plain_str + j) = *str1;
            str1++;
        }
    }
//    j++;
    *(plain_str + j) = '\x00';

    return(plain_str);
}

/*
int main()
{
    char *plain_str = NULL;

    plain_str = hex_decode("..%2f..%2f..%2f%2f%2f%20%2c%41%41%41%78%78%78%90%90%90-PLAIN-TEXT-\0" );
    printf("Hex Decoded: %s\n", plain_str);

    if(plain_str != NULL)
    {
        free(plain_str);
        plain_str = NULL;
    }
}

*/
