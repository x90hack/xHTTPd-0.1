#include <stdio.h>

int main()
{
	char buf[1024];
	char buf2[3000];
	int i = 0;

	memset(buf, (char *)0x41, 1023);

	sprintf(buf2, "curl http://192.168.134.10/index.html?a=%s", buf);

	for(i = 0; i < 10000; i++)
	{
          system(buf2);	
	}
}
