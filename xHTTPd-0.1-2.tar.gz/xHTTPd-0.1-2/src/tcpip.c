/*
 * xHTTPd daemon.
 * Copyright(c) x90 all rights reserved.
 * Email: x90cx90c1@gmail.com
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "main.h"

/*
 * ���� �ʱ�ȭ ( Create )
*/
int 
init_sock( struct sockaddr_in *psock, int *psock_id, char *ipaddr, int port )
{
   if( port <= 0 || port >= 65535 )
   {
      fprintf( stderr, "init_sock:: improper port number to create a socket." );
      return -1;
   }

   memset( (void * )psock, 0, sizeof( struct sockaddr_in ) );
   psock->sin_family = AF_INET;
   psock->sin_addr.s_addr = inet_addr( ipaddr );
   psock->sin_port = htons( port );

   if( ( *psock_id = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP ) ) == -1 )
   {
        fprintf( stderr, "init_sock:: socket creation failed.\n" );
        return -1;
   }
   
   return 0;
}

/*
 * ���� ���� ( ���� ������ ī��Ʈ ���� )
*/
int
close_sock( struct _CLIENT *pClient, int sock_id )
{

    pClient->current_user--;
    close( sock_id );
}

/*
 * ���� ����Ÿ ����
*/
int 
sock_send( int sock_id, char *data, int len )
{
    int bytes = 0;
    int i = 0;
    int total_bytes = len;

    if( ( bytes = send( sock_id, ( void * ) data, len, 0 ) ) == -1 )
    {
        fprintf( stderr, "sock_send:: failed to send packet\n" );
        return -1;
    }
   
    if( bytes != -1 )
    {
        total_bytes -= bytes;
    }

    while( total_bytes != 0 )
    {
        bytes = send( sock_id, ( void * ) ( data + ( len - total_bytes ) ), 
                      total_bytes, 0 );
        if( bytes != -1 )
        {
            total_bytes -= bytes;
        }
        else
        {
            return -1;
        }
    }

    return len;
}

/*
 * ���� ����Ÿ ����
*/
int 
sock_recv( int sock_id, char *data, int len )
{
    int bytes = 0;
    
    if((bytes = recv( sock_id, ( void * ) data, len, 0 ) ) < 0)
    {
        return -1;
    }
    
    return bytes;
}

/*
 * ���� ������ �ʱ�ȭ ( Listening )
*/
int 
init_server_thread( struct sockaddr_in *pserv_sock, int *psock_id, int port, int max_user)
{
   struct sockaddr_in serv_sock;
   int sock_fd = 0;
   int optval = 0;
   
   memset( ( void * )&serv_sock, 0, sizeof( struct sockaddr_in ) );
   serv_sock.sin_family = AF_INET;
   serv_sock.sin_addr.s_addr = INADDR_ANY;
   serv_sock.sin_port = htons( port );

   if( ( sock_fd = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP ) ) <= 0 )
   {
        fprintf( stderr, "init_server_thread():: server socket creation failed!\n" );
        close( sock_fd );
        return -1;
   }

   setsockopt( sock_fd, SOL_SOCKET, SO_LINGER, &optval, sizeof(optval));

   if( setsockopt( sock_fd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval) )
        == -1 ){
        fprintf( stderr, "init_server_thread():: server address reuse failed!\n" );
   }


   if( bind( sock_fd, (struct sockaddr *) &serv_sock, sizeof( struct sockaddr ) ) == -1 )
   {
        fprintf( stderr, "init_server_thread():: server socket binding failed\n" );
        close( sock_fd );
        return -2;
   }

   if( listen( sock_fd, MAX_USER ) == -1 )
   {
        fprintf( stderr, "init_server_thread():: server socket listen failed !\n" );
        return -3;
   }

   memset( ( void * ) pserv_sock, 0, sizeof( struct sockaddr_in ) );
   pserv_sock->sin_family = serv_sock.sin_family;
   pserv_sock->sin_addr.s_addr = serv_sock.sin_addr.s_addr;
   pserv_sock->sin_port = serv_sock.sin_port;

   *psock_id = sock_fd;
//   printf( "���� ���� �ʱ�ȭ��... Daemon %d ��Ʈ, �ִ� �����: %d\n", port, max_user );
   
   return 0;
}
