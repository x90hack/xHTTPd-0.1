<?php
// var_dump($argv);

$test_arg = $argv[1];

echo "test_arg variable from argv[1] = '".$test_arg."'";


?>

