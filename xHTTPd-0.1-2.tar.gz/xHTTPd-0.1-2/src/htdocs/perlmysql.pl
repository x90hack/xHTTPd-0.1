#!/usr/bin/perl
use strict;
use warnings;
use v5.10; # for say() function

# reference: https://www.mysqltutorial.org/perl-mysql/perl-mysql-connect/
# reference: sudo apt-get install libdbi-perl
# reference: sudo apt-get install libdbd-mysql-perl

use DBI;
say "Perl MySQL Connect Demo";
# MySQL database configuration

use DBI;

my $database = "perlmysqldb";
my $hostname = "localhost";
my $port = 3306;
my $user = "root";
my $password = "1234";
 
my $dsn = "DBI:mysql:database=$database;host=$hostname;port=$port";
my $dbh = DBI->connect($dsn, $user, $password);
 
say "Connected to the MySQL database.";

