#!/usr/bin/perl
use CGI qw(param);

my $user = param("user");
my $pass = param("pass");

print "mod_perl.c test!! <br>( ex. perl_test.pl?user=x90c&pass=1234 )<br";
print "( passing user suppiled arguments into perl! )<br><br>"."\n";

if($user eq "x90c" && $pass eq "1234")
{ 
    print "<br><font color=blue><b>$user:$pass auth ok!</b></font>\n";
} else {
    print "<br><font color=red><b>$user:$pass auth failed!</b></font>\n";
}
